package com.example.filmandroidapplication.activity.auth;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import com.example.filmandroidapplication.databinding.ActivitySignInBinding;
import com.example.filmandroidapplication.model.component.user.UserService;
import com.example.filmandroidapplication.model.component.user.impl.UserServiceImpl;
import com.example.filmandroidapplication.model.factory.AlertFactory;
import com.example.filmandroidapplication.model.factory.UserFactory;
import com.example.filmandroidapplication.model.service.AlertService;

public class SignInActivity extends AppCompatActivity {
    // Объявление переменных для сервисов пользователя и оповещений, а также для связывания представления активности
    private UserService userService;
    private AlertService alertService;
    private ActivitySignInBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // Инициализация представления активности с помощью ViewBinding
        binding = ActivitySignInBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        // Получение экземпляров сервисов пользователя и оповещений
        userService = UserFactory.getInstance().getUserComponent(getBaseContext());
        alertService = AlertFactory.getInstance().getAlertFactory(this);

        // Обработчик нажатия кнопки входа
        binding.button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String email = binding.email.getText().toString();
                String password = binding.password.getText().toString();

                // Проверка, что поля email и password не пустые
                if (email == null || password == null) {
                    // Если поля пустые, показать оповещение
                    alertService.alert("ОК", "Заполните все данные!");
                } else {
                    // Попытка аутентификации пользователя
                    if (userService.authUser(email, password) != null) {
                        // Если аутентификация прошла успешно, завершить активность
                        setResult(200);
                        finish();
                    } else {
                        // Если аутентификация не удалась, показать оповещение
                        alertService.alert("ОК", "Неправильный логин или пароль");
                    }
                }
            }
        });

        // Обработчик нажатия ссылки для перехода на экран регистрации
        binding.signUpLink.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Создание намерения для запуска активности регистрации
                Intent intent = new Intent(getBaseContext(), SignUpActivity.class);
                startActivityForResult(intent, 200);
                setResult(200);
                finish();
            }
        });
    }
}