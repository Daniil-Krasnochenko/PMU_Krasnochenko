package com.example.filmandroidapplication.model.factory;

import com.example.filmandroidapplication.model.component.comment.CommentService;
import com.example.filmandroidapplication.model.component.comment.impl.CommentServiceImpl;

// DI CommentService с реализацией CommentServiceImpl
public class CommentFactory {
    private static CommentFactory commentFactory;

    private CommentFactory() {

    }

    public static CommentFactory getInstance() {
        if (commentFactory == null) {
            synchronized (CommentFactory.class) {
                commentFactory = new CommentFactory();
                ;
            }
        }
        return commentFactory;
    }


    public CommentService commentService() {
        return new CommentServiceImpl();
    }
}
