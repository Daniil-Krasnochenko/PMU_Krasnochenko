package com.example.filmandroidapplication.model.component.user;

import android.content.Context;

import com.example.filmandroidapplication.model.entity.user.User;

public interface UserService {
    void update(Context context);

    boolean regUser(String email, String password);

    User auth();

    User authUser(String email, String password);

    User getUserByEmail(String email);

    User getUser();
}
