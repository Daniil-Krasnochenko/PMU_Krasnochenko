package com.example.filmandroidapplication.config;

public class Config {
    // конфигурация подключения к бд
    public static final String HOST = "100.65.4.52";
    // public static final String HOST = "10.0.2.2";
    public static final String USER = "root";
    public static final String PASSWORD = "Dert869$$";

    public static final String DATABASE = "films";

    // countries
    public static final String[] country = new String[]{
            "Россия", "США", "Англия", "Китай"
    };
}
