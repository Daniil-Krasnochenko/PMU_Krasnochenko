package com.example.filmandroidapplication.model.component.genre.impl;

import com.example.filmandroidapplication.model.component.database.Database;
import com.example.filmandroidapplication.model.component.genre.GenreService;
import com.example.filmandroidapplication.model.entity.film.Film;
import com.example.filmandroidapplication.model.entity.film.data.Genre;
import com.example.filmandroidapplication.model.factory.DatabaseFactory;

import java.util.List;

public class GenreServiceImpl implements GenreService {

    private Database database;


    public GenreServiceImpl() {
        database = DatabaseFactory.getInstance().getDatabase();

    }

    // найти все фильмы
    @Override
    public List<Genre> findAllGenre() {
        String sql = "SELECT * FROM genre";
        return database.findAll(sql, Genre.class);
    }

    // сохранить все жанры для фильмов
    @Override
    public void put(Film film, List<Genre> genres) {
        for (Genre genre : genres) {
            String sql = "INSERT INTO genre_film (film_id,genre_id) VALUES (?,?)";
            database.insert(sql, film.getId(), genre.getId());
        }
    }


    // найти жанры для определенного фильма
    @Override
    public List<Genre> findGenreByFilm(Film film) {
        String sql = "SELECT * FROM genre_film LEFT JOIN genre ON genre.id = genre_film.genre_id WHERE film_id = ?";
        return database.findAll(sql, Genre.class, film.getId());
    }


}
