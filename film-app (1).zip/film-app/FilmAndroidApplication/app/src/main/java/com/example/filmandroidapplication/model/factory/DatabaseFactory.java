package com.example.filmandroidapplication.model.factory;


import com.example.filmandroidapplication.model.component.database.Database;
import com.example.filmandroidapplication.model.component.database.impl.DatabaseImpl;

// DI для базы данных DatabaseImpl
public class DatabaseFactory {
    private static DatabaseFactory databaseFactory = null;

    private Database database;

    private DatabaseFactory() {

    }


    public static DatabaseFactory getInstance() {
        if (databaseFactory == null) {
            synchronized (DatabaseFactory.class) {
                databaseFactory = new DatabaseFactory();
            }
        }
        return databaseFactory;
    }

    public Database getDatabase() {
        if (database == null) {
            database = new DatabaseImpl();
        }
        return database;
    }

}
