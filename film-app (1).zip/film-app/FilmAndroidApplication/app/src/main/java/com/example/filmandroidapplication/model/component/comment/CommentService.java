package com.example.filmandroidapplication.model.component.comment;

import com.example.filmandroidapplication.model.entity.comment.Comment;
import com.example.filmandroidapplication.model.entity.film.Film;
import com.example.filmandroidapplication.model.entity.user.User;

import java.util.List;

public interface CommentService {
    void insertComment(Film film, User user, String comment);
    List<Comment> getComments(Film film);

}
