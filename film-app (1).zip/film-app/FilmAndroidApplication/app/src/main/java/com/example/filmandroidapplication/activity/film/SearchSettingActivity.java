package com.example.filmandroidapplication.activity.film;

import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;

import com.example.filmandroidapplication.R;
import com.example.filmandroidapplication.adapter.GenreFilterAdapter;
import com.example.filmandroidapplication.config.Config;
import com.example.filmandroidapplication.databinding.ActivitySearchSettingBinding;
import com.example.filmandroidapplication.model.component.country.CountryService;
import com.example.filmandroidapplication.model.component.film.FilmService;
import com.example.filmandroidapplication.model.component.genre.GenreService;
import com.example.filmandroidapplication.model.component.storage.StorageService;
import com.example.filmandroidapplication.model.entity.film.data.Country;
import com.example.filmandroidapplication.model.entity.film.data.Genre;
import com.example.filmandroidapplication.model.entity.film.data.Year;
import com.example.filmandroidapplication.model.factory.AlertFactory;
import com.example.filmandroidapplication.model.factory.CountryFactory;
import com.example.filmandroidapplication.model.factory.FilmFactory;
import com.example.filmandroidapplication.model.factory.GenreFactory;
import com.example.filmandroidapplication.model.factory.StorageFactory;
import com.example.filmandroidapplication.model.service.AlertService;

import java.util.Arrays;
import java.util.List;

public class SearchSettingActivity extends AppCompatActivity {

    private Country country;
    private Year year;
    private GenreService genreService;
    private CountryService countryService;
    private AlertService alertService;
    private StorageService storageService;

    private ActivitySearchSettingBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        binding = ActivitySearchSettingBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        storageService = StorageFactory.getInstance().storageService();

        genreService = GenreFactory.getInstance().genreService();
        countryService = CountryFactory.getInstance().countryService();
        alertService = AlertFactory.getInstance().getAlertFactory(this);

        List<Genre> genres = genreService.findAllGenre();
        List<Country> countries = countryService.findAllCountry();
        List<Year> years = countryService.findAllExistYear();

        countries.add(new Country("Нет"));
        years.add(new Year());

        //filter country start
        ArrayAdapter<String> filterCountryAdapter = new ArrayAdapter<>(this,
                android.R.layout.simple_spinner_item,

                countries.stream().map(Country::getCountry).toArray(String[]::new)

        );
        binding.filterCountry.setAdapter(filterCountryAdapter);
        binding.filterCountry.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                country = countries.get(i);

            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });
        //filter country end

        // filter year start
        ArrayAdapter<String> filterYearAdapter = new ArrayAdapter<>(this,
                android.R.layout.simple_spinner_item,

                years.stream().map(Year::getText).toArray(String[]::new)

        );
        binding.filterYear.setAdapter(filterYearAdapter);
        binding.filterYear.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                year = years.get(i);
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });
        //filter year end


        GenreFilterAdapter genreFilterAdapter = new GenreFilterAdapter(this, R.layout.film_view, genres);
        binding.filterGenreList.setAdapter(genreFilterAdapter);

        binding.filterSelectButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                storageService.getData().setCountry(country);
                storageService.getData().setYear(year);
                storageService.getData().setGenres(genreFilterAdapter.getSelected());
                setResult(201);
                finish();

            }
        });

    }


}




















