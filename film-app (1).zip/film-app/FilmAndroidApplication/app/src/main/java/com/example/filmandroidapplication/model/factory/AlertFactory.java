package com.example.filmandroidapplication.model.factory;

import android.app.Activity;

import com.example.filmandroidapplication.model.service.AlertService;
import com.example.filmandroidapplication.model.service.impl.AlertServiceImpl;

// DI AlertService с реализацией AlertServiceImpl
public class AlertFactory {
    private static AlertFactory alertFactory;

    private AlertFactory() {

    }

    public static AlertFactory getInstance() {
        if (alertFactory == null) {
            synchronized (AlertFactory.class) {
                alertFactory = new AlertFactory();
            }
        }
        return alertFactory;
    }

    public AlertService getAlertFactory(Activity activity) {
        return new AlertServiceImpl(activity);
    }
}
