package com.example.filmandroidapplication.model.factory;

import com.example.filmandroidapplication.model.component.film.FilmService;
import com.example.filmandroidapplication.model.component.film.impl.FilmServiceImpl;

//  DI FilmService  реализация FilmServiceImpl
public class FilmFactory {
    private static FilmFactory filmFactory = null;

    public static FilmFactory getInstance() {
        if (filmFactory == null) {
            synchronized (FilmFactory.class) {
                filmFactory = new FilmFactory();
            }

        }
        return filmFactory;
    }

    public FilmService filmService() {
        return new FilmServiceImpl();
    }
}
