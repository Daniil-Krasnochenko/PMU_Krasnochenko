package com.example.filmandroidapplication.model.component.storage;

public interface StorageService {
    Data getData();
}
