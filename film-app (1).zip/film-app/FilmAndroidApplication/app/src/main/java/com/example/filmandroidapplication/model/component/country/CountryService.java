package com.example.filmandroidapplication.model.component.country;

import com.example.filmandroidapplication.model.entity.film.data.Country;
import com.example.filmandroidapplication.model.entity.film.data.Year;

import java.util.List;

public interface CountryService {


    List<Country> findAllCountry();

    List<Year> findAllExistYear();
}
