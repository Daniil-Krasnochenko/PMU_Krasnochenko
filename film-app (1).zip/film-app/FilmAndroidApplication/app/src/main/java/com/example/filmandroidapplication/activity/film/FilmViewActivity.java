package com.example.filmandroidapplication.activity.film;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentTransaction;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.util.Base64;
import android.view.View;

import com.example.filmandroidapplication.R;
import com.example.filmandroidapplication.activity.film.ui.CommentViewFragment;
import com.example.filmandroidapplication.databinding.ActivityFilmViewBinding;
import com.example.filmandroidapplication.model.component.comment.CommentService;
import com.example.filmandroidapplication.model.component.film.FilmService;
import com.example.filmandroidapplication.model.component.genre.GenreService;
import com.example.filmandroidapplication.model.component.user.UserService;
import com.example.filmandroidapplication.model.entity.comment.Comment;
import com.example.filmandroidapplication.model.entity.film.Film;
import com.example.filmandroidapplication.model.entity.film.data.Genre;
import com.example.filmandroidapplication.model.factory.AlertFactory;
import com.example.filmandroidapplication.model.factory.CommentFactory;
import com.example.filmandroidapplication.model.factory.FilmFactory;
import com.example.filmandroidapplication.model.factory.GenreFactory;
import com.example.filmandroidapplication.model.factory.UserFactory;
import com.example.filmandroidapplication.model.service.AlertService;

import java.util.Arrays;
import java.util.List;

public class FilmViewActivity extends AppCompatActivity {


    private AlertService alertService;
    private FilmService filmService;
    private CommentService commentService;
    private UserService userService;
    private GenreService genreService;


    private Film film;
    private List<Comment> comments;

    private ActivityFilmViewBinding binding;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityFilmViewBinding.inflate(getLayoutInflater());

        setContentView(binding.getRoot());

        filmService = FilmFactory.getInstance().filmService();
        commentService = CommentFactory.getInstance().commentService();
        userService = UserFactory.getInstance().getUserComponent(getApplicationContext());
        alertService = AlertFactory.getInstance().getAlertFactory(this);
        genreService = GenreFactory.getInstance().genreService();

        Integer filmId = getIntent().getIntExtra("film", 0);
        if (filmId == null) {
            finish();
        }
        if (userService.getUser() == null) {

            film = filmService.getFilmById(filmId);
        } else {
            film = filmService.getFilmByIdForUser(filmId, userService.getUser());
        }
        if (film == null) {
            finish();
        }


        binding.country.setText(film.getCountry());
        binding.name.setText(film.getName());
        binding.desc.setText(film.getDescription().substring(0, film.getDescription().length() > 200 ? 200 : film.getDescription().length() - 1));
        binding.yearOfFilmView.setText(String.valueOf(film.getYear()) + " год");

        binding.photo.setImageBitmap(base64ToBitmap(film.getImage()));
        binding.comments.setText(film.getComment_count() + " Отзывов");


        if (film.getFilm_id() == null) {

            binding.fav.setImageDrawable(getApplicationContext().getResources().getDrawable(android.R.drawable.star_big_off));
        } else {

            binding.fav.setImageDrawable(getApplicationContext().getResources().getDrawable(android.R.drawable.star_big_on));
        }

        binding.fav.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (userService.getUser() != null) {
                    if (film.getFilm_id() == null) {
                        filmService.addFavorite(film, userService.getUser());
                        film.setFilm_id(1);
                    } else {
                        filmService.removeFavorite(film, userService.getUser());
                        film.setFilm_id(null);
                    }
                    if (film.getFilm_id() == null) {

                        binding.fav.setImageDrawable(getApplicationContext().getResources().getDrawable(android.R.drawable.star_big_off));
                    } else {

                        binding.fav.setImageDrawable(getApplicationContext().getResources().getDrawable(android.R.drawable.star_big_on));
                    }
                } else {
                    alertService.alert("OK", "Авторизуйтесь на главное странице!");
                }
            }
        });


        binding.commentButtonSend.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (userService.getUser() == null) {
                    alertService.alert("OK", "Авторизуйтесь, чтобы оставить комментарий!");
                    return;
                }
                String comment = binding.commentTextSend.getText().toString();
                if (comment == null || comment.isEmpty() || comment.length() < 3) {
                    alertService.alert("OK", "Минимальная длинна комментария 3 символа");
                    return;
                }
                commentService.insertComment(film, userService.getUser(), comment);
                Comment commentObject = new Comment();
                commentObject.setEmail(userService.getUser().getEmail());
                commentObject.setComment(comment);
                comments.add(commentObject);

                addCommentToView(commentObject);

                binding.commentTextSend.setText("");

            }
        });


        binding.backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                setResult(200);
                finish();
            }
        });

        comments = commentService.getComments(film);


        for (Comment comment : comments) {
            addCommentToView(comment);
        }


        List<Genre> genres = genreService.findGenreByFilm(film);
        String[] arr = (String[]) genres.stream().map(Genre::getName).toArray(String[]::new);
        binding.genre.setText("Жанры: " + String.join(", ", arr));
    }

    private void addCommentToView(Comment comment) {
        CommentViewFragment commentViewFragment = new CommentViewFragment(comment);
        FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();
        transaction.add(R.id.comments_layout, commentViewFragment);
        transaction.commit();
    }

    private Bitmap base64ToBitmap(String base64String) {
        byte[] decodedBytes = Base64.decode(base64String, Base64.DEFAULT);
        return BitmapFactory.decodeByteArray(decodedBytes, 0, decodedBytes.length);
    }
}