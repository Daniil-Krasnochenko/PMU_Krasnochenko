package com.example.filmandroidapplication.model.component.comment.impl;

import com.example.filmandroidapplication.model.component.comment.CommentService;
import com.example.filmandroidapplication.model.component.database.Database;
import com.example.filmandroidapplication.model.entity.comment.Comment;
import com.example.filmandroidapplication.model.entity.film.Film;
import com.example.filmandroidapplication.model.entity.user.User;
import com.example.filmandroidapplication.model.factory.DatabaseFactory;

import java.util.List;

public class CommentServiceImpl implements CommentService {

    private Database database;


    public CommentServiceImpl() {
        database = DatabaseFactory.getInstance().getDatabase();
    }

    //  внести комментарий
    @Override
    public void insertComment(Film film, User user, String comment) {
        String sql = "INSERT INTO comment (user,comment,film) VALUES (?,?,?)";
        database.insert(sql, user.getId(), comment, film.getId());
    }

    // получить все комментарии к фильму
    @Override
    public List<Comment> getComments(Film film) {
        String sql = "SELECT * FROM comment LEFT JOIN users ON comment.user = users.id";
        return database.findAll(sql, Comment.class);
    }
}
