package com.example.filmandroidapplication.adapter;

import android.app.Activity;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.CompoundButton;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.example.filmandroidapplication.databinding.GenreViewBinding;
import com.example.filmandroidapplication.model.entity.film.data.Genre;

import java.util.ArrayList;
import java.util.List;

public class GenreFilterAdapter extends ArrayAdapter<Genre> {
    private List<Genre> selected = new ArrayList<>();
    private Activity activity;
    private Context context;

    private List<Genre> genres;

    public GenreFilterAdapter(Activity activity, int resource, List<Genre> genres) {
        super(activity.getApplicationContext(), resource, genres);
        this.activity = activity;
        this.context = activity.getApplicationContext();
        this.genres = genres;
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
        GenreViewBinding binding = GenreViewBinding.inflate(inflater);


        Genre genre = genres.get(position);

        // установка названия жанра
        binding.box.setText(genre.getName());
        binding.box.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {
                if (b) {
                    selected.add(genre);

                } else {
                    selected.remove(genre);
                }
            }
        });

        return binding.getRoot();
    }

    public List<Genre> getSelected() {
        return selected;
    }


}
