package com.example.filmandroidapplication.model.factory;

import com.example.filmandroidapplication.model.component.genre.GenreService;
import com.example.filmandroidapplication.model.component.genre.impl.GenreServiceImpl;

public class GenreFactory {

    private static GenreFactory genreFactory;


    private GenreFactory() {

    }

    public static GenreFactory getInstance() {
        if (genreFactory == null) {
            synchronized (GenreFactory.class) {
                genreFactory = new GenreFactory();
            }
        }
        return genreFactory;
    }

    public GenreService genreService() {
        return new GenreServiceImpl();
    }
}
