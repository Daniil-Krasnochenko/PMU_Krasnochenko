package com.example.filmandroidapplication;

import android.content.Intent;
import android.os.Bundle;

import com.example.filmandroidapplication.databinding.ActivityMainBinding;
import com.example.filmandroidapplication.model.factory.StorageFactory;
import com.example.filmandroidapplication.ui.favorite.FavoriteFragment;
import com.example.filmandroidapplication.ui.home.HomeFragment;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;

public class MainActivity extends AppCompatActivity {

    HomeFragment homeFragment;
    FavoriteFragment favoriteFragment;
    private ActivityMainBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        homeFragment = new HomeFragment(this);
        favoriteFragment = new FavoriteFragment(this);


        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        binding.bottomNavigationView.setOnNavigationItemSelectedListener(item -> {
            if (item.getItemId() == R.id.navigation_home) {
                setCurrentFragment(homeFragment);
            } else if (item.getItemId() == R.id.navigation_dashboard) {
                setCurrentFragment(favoriteFragment);
            }

            return true;
        });

        binding.bottomNavigationView.setSelectedItemId(R.id.navigation_home);

    }

    private void setCurrentFragment(Fragment fragment) {
        getSupportFragmentManager().beginTransaction().replace(R.id.flFragment, fragment).commit();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {

        if (resultCode == 200) {

            // вызвать родительский метод
            super.onActivityResult(requestCode, resultCode, data);

            // очищаем страницы после добавления нового фильма,авторизации или что-то еще
            homeFragment = new HomeFragment(this);
            favoriteFragment = new FavoriteFragment(this);
            // выбираем для сброса самый первый
            binding.bottomNavigationView.setSelectedItemId(R.id.navigation_home);

        } else if (resultCode == 201) {
            homeFragment.update();
            StorageFactory.getInstance().updateStorage();
        }
    }
}


