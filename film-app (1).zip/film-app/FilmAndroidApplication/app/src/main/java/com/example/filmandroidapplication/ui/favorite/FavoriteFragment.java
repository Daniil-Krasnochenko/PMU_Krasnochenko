package com.example.filmandroidapplication.ui.favorite;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

import com.example.filmandroidapplication.R;
import com.example.filmandroidapplication.activity.auth.SignInActivity;
import com.example.filmandroidapplication.adapter.FilmFavoriteArrayAdapter;
import com.example.filmandroidapplication.databinding.FragmentFavoriteBinding;
import com.example.filmandroidapplication.model.component.film.FilmService;
import com.example.filmandroidapplication.model.component.user.UserService;
import com.example.filmandroidapplication.model.entity.film.Film;
import com.example.filmandroidapplication.model.factory.FilmFactory;
import com.example.filmandroidapplication.model.factory.UserFactory;

import java.util.List;

public class FavoriteFragment extends Fragment {

    // Объявление переменных
    private Activity activity;
    private UserService userService;
    private FilmService filmService;
    private FragmentFavoriteBinding binding;

    // Конструктор фрагмента, принимающий Activity
    public FavoriteFragment(Activity activity) {
        this.activity = activity;
    }

    // Метод, вызываемый при создании View фрагмента
    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {

        // Инициализация FragmentFavoriteBinding
        binding = FragmentFavoriteBinding.inflate(inflater, container, false);

        // Получение экземпляров UserService и FilmService
        userService = UserFactory.getInstance().getUserComponent(getContext());
        filmService = FilmFactory.getInstance().filmService();

        // Обработчик нажатия кнопки авторизации
        binding.authButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Переход к экрану авторизации
                Intent intent = new Intent(getContext(), SignInActivity.class);
                startActivityForResult(intent, 200);
            }
        });

        // Проверка, авторизован ли пользователь
        if (userService.getUser() != null) {
            // Если авторизован, показываем список избранных фильмов
            binding.noAuthLayout.setVisibility(View.GONE);
            binding.authLayout.setVisibility(View.VISIBLE);

            // Получение списка избранных фильмов
            List<Film> films = filmService.findFavoriteFilmList(userService.getUser());
            if (films.size() > 0) {
                // Если есть избранные фильмы, создаем адаптер и устанавливаем его для списка
                FilmFavoriteArrayAdapter filmArrayAdapter = new FilmFavoriteArrayAdapter(activity, R.layout.film_view, films, filmService, userService, binding);
                binding.listFilm.setAdapter(filmArrayAdapter);
                binding.listFilm.setOnItemClickListener(filmArrayAdapter);
            } else {
                // Если нет избранных фильмов, показываем соответствующее сообщение
                binding.authLayout.setVisibility(View.GONE);
                binding.notFound.setVisibility(View.VISIBLE);
            }
        } else {
            // Если пользователь не авторизован, показываем экран авторизации
            binding.noAuthLayout.setVisibility(View.VISIBLE);
            binding.authLayout.setVisibility(View.GONE);
        }

        // Возвращаем корневой View фрагмента
        return binding.getRoot();
    }

    // Метод, вызываемый при уничтожении View фрагмента
    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}