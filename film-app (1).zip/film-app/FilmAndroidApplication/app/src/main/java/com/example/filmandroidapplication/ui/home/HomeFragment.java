package com.example.filmandroidapplication.ui.home;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

import com.example.filmandroidapplication.R;
import com.example.filmandroidapplication.activity.auth.SignInActivity;
import com.example.filmandroidapplication.activity.film.CreateFilmActivity;
import com.example.filmandroidapplication.activity.film.SearchSettingActivity;
import com.example.filmandroidapplication.adapter.FilmArrayAdapter;
import com.example.filmandroidapplication.databinding.FragmentHomeBinding;
import com.example.filmandroidapplication.model.component.film.FilmService;
import com.example.filmandroidapplication.model.component.storage.Data;
import com.example.filmandroidapplication.model.component.user.UserService;
import com.example.filmandroidapplication.model.entity.film.Film;
import com.example.filmandroidapplication.model.entity.film.data.Country;
import com.example.filmandroidapplication.model.entity.film.data.Year;
import com.example.filmandroidapplication.model.factory.FilmFactory;
import com.example.filmandroidapplication.model.factory.StorageFactory;
import com.example.filmandroidapplication.model.factory.UserFactory;

import java.util.List;

// Это фрагмент - не путать с активностью
public class HomeFragment extends Fragment {


    private UserService userService;
    private FilmService filmService;

    private FragmentHomeBinding binding;
    private FilmArrayAdapter filmArrayAdapter;
    private Activity activity;
    private List<Film> list = null;

    public HomeFragment(Activity activity) {
        this.activity = activity;
    }

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {


        binding = FragmentHomeBinding.inflate(inflater, container, false);

        userService = UserFactory.getInstance().getUserComponent(getContext());
        filmService = FilmFactory.getInstance().filmService();

        if (userService.auth() != null) {

            binding.auth.setVisibility(View.GONE);
            binding.addFilm.setVisibility(View.VISIBLE);

        }

        binding.auth.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getContext(), SignInActivity.class);
                startActivityForResult(intent, 200);
            }
        });

        binding.addFilm.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getContext(), CreateFilmActivity.class);
                startActivityForResult(intent, 200);
            }
        });


        if (userService.getUser() == null) {
            list = filmService.findFilmList();
        } else {
            list = filmService.findFilmList(userService.getUser());
        }
        Log.e("[FILM]", list.toString());


        // Создание и установка адаптера для списка фильмов
        filmArrayAdapter = new FilmArrayAdapter(activity, R.layout.film_view, list, filmService, userService);
        binding.listFilm.setAdapter(filmArrayAdapter);
        binding.listFilm.setOnItemClickListener(filmArrayAdapter);

        // Обработчик нажатия кнопки поиска
        binding.searchButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                update();
            }
        });

        // при нажатии на кнопку настройки открывается активность с выбором фильтров
        binding.settingSerachButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getContext(), SearchSettingActivity.class);
                startActivityForResult(intent, 201);
            }
        });
        return binding.getRoot();
    }


    // Метод для поиска фильмов по заданным параметрам
    private void searchFilms() {
        // DI получение информации из поиска,чтобы не вынимать их из extra data
        Data dataSearch = StorageFactory.getInstance().storageService().getData();

        // Текст(Название поиска)
        String query = binding.searchSrcText.getText().toString();

        //  DI получаем из filmService фильмы по параметрам
        List<Film> films = null;
        if (userService.getUser() == null) {
            films = filmService.findFilmByParameters(dataSearch.getGenres(), dataSearch.getYear(), dataSearch.getCountry(), query);
        } else {
            films = filmService.findFilmByParameters(dataSearch.getGenres(), dataSearch.getYear(), dataSearch.getCountry(), query, userService.getUser());
        }
        // чистим предыдущий лист фильмов
        list.clear();
        list.addAll(films);
        filmArrayAdapter.notifyDataSetChanged();
    }

    // Метод для обновления списка фильмов
    public void update() {
        Log.e("[DATA]", StorageFactory.getInstance().storageService().getData().toString());
        searchFilms();
    }

    // Метод, вызываемый при уничтожении View фрагмента
    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }

}