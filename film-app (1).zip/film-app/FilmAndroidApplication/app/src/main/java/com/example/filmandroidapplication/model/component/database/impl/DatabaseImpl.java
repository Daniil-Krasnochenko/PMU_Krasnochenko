package com.example.filmandroidapplication.model.component.database.impl;

import android.os.StrictMode;
import android.util.Log;

import com.example.filmandroidapplication.config.Config;
import com.example.filmandroidapplication.model.component.database.Database;

import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

// Реализация интерфейса Database по принципам SOLID (мы должны зависеть от абстракции, а не от реализации)
public class DatabaseImpl implements Database {


    public DatabaseImpl() {
        try {
            init();
        } catch (ClassNotFoundException | NoSuchMethodException | InvocationTargetException |
                 IllegalAccessException | InstantiationException e) {
            throw new RuntimeException(e);
        }
    }


    private void init() throws ClassNotFoundException, NoSuchMethodException, InvocationTargetException, IllegalAccessException, InstantiationException {

        Class.forName("com.mysql.jdbc.Driver");
        // Class.forName("com.mysql.cj.jdbc.Driver").getDeclaredConstructor().newInstance();


    }


    // подключение к бд(екаждый раз новое,для того чтобы не делать улавливатель для переподключения к бд)
    private Connection connectToDatabase() {
        StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
        StrictMode.setThreadPolicy(policy);

        String url = "jdbc:mysql://" + Config.HOST + ":3306/" + Config.DATABASE + "";

        try {
            return DriverManager.getConnection(url, Config.USER, Config.PASSWORD);
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    // внесение данных в бд
    @Override
    public int insert(String sql, Object... args) {
        Connection connection = connectToDatabase();

        try {
            // Создаем подготовленное выражение для выполнения SQL запроса
            PreparedStatement statement = connection.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS);

            // Устанавливаем значения параметров в подготовленном выражении
            for (int i = 0; i < args.length; i++) {
                statement.setObject(i + 1, args[i]);
            }

            // Выполняем SQL запрос для вставки данных

            statement.executeUpdate();

            // получаем результат добавления (тоесть id)
            ResultSet resultSet = statement.getGeneratedKeys();
            if (resultSet.next()) {
                int id = resultSet.getInt(1);

                // Закрываем подготовленное выражение
                statement.close();
                resultSet.close();
                connection.close();
                return id;
            } else {
                return -1;
            }


        } catch (SQLException e) {
            throw new RuntimeException("Error executing insert query: " + e.getMessage());
        }
    }


    // поиск всех данных из бд (тоесть не одну строку)
    @Override
    public <T> List<T> findAll(String sql, Class<T> tClass, Object... args) {
        Connection connection = connectToDatabase();
        List<T> results = new ArrayList<>();

        try {

            // Создаем подготовленное выражение для выполнения SQL запроса
            PreparedStatement statement = connection.prepareStatement(sql);

            // Устанавливаем значения параметров в подготовленном выражении
            for (int i = 0; i < args.length; i++) {
                statement.setObject(i + 1, args[i]);
            }

            // Выполняем SQL запрос для выборки данных
            ResultSet resultSet = statement.executeQuery();

            // Обработка результата выборки данных
            while (resultSet.next()) {
                // В зависимости от типа T,можно извлечь данные из resultSet и создать объект типа T
                // Например, если T - это объект модели данных, то извлекаем данные из resultSet и создаем объект модели
                T result = createObjectFromResultSet(resultSet, tClass);
                results.add(result);
            }

            // Закрываем resultSet и подготовленное выражение
            resultSet.close();
            statement.close();
            connection.close();
            return results;
        } catch (SQLException e) {
            throw new RuntimeException("Error executing query: " + e.getMessage());
        }


    }

    // выполнить простой запрос получения одной строки
    @Override
    public <T> T query(String sql, Class<T> tClass, Object... args) {
        Connection connection = connectToDatabase();
        T result = null;
        try {
            // Создаем подготовленное выражение для выполнения SQL запроса
            PreparedStatement statement = connection.prepareStatement(sql);

            // Устанавливаем значения параметров в подготовленном выражении
            for (int i = 0; i < args.length; i++) {
                statement.setObject(i + 1, args[i]);
            }

            // Выполняем SQL запрос для выборки данных
            ResultSet resultSet = statement.executeQuery();

            // Обработка результата выборки данных
            if (resultSet.next()) {
                // В зависимости от типа T,можно извлечь данные из resultSet и создать объект типа T
                // Например, если T - это объект модели данных, то извлекаем данные из resultSet и создаем объект модели
                result = createObjectFromResultSet(resultSet, tClass);
            }

            // Закрываем resultSet и подготовленное выражение
            resultSet.close();
            statement.close();
            connection.close();
        } catch (SQLException e) {
            throw new RuntimeException("Error executing query: " + e.getMessage());
        }

        return result;
    }


    // получить из возвращенных данных DTO из entity пакета в определенный класс Class<T> tClass
    private <T> T createObjectFromResultSet(ResultSet resultSet, Class<T> tClass) throws SQLException {
        try {
            // Создаем новый экземпляр объекта типа T
            T object = tClass.getDeclaredConstructor().newInstance();

            // Получаем метаданные результата выборки
            ResultSetMetaData metaData = resultSet.getMetaData();
            int columnCount = metaData.getColumnCount();

            // Извлекаем данные из resultSet и устанавливаем их в объект
            for (int i = 1; i <= columnCount; i++) {
                String columnName = metaData.getColumnName(i);
                Object columnValue = resultSet.getObject(i);

                if (doesObjectContainField(tClass, columnName)) {
                    Log.e("[FIELD]", columnName);
                    // Используем рефлексию для установки значения поля объекта
                    Field field = tClass.getDeclaredField(columnName);
                    field.setAccessible(true);
                /*
                    // Проверяем тип поля и преобразуем значение, если необходимо
                    if (field.getType() == Long.class && columnValue instanceof Integer && columnName.equals("id")) {
                        columnValue = ((Integer) columnValue).longValue();
                    }
                */
                    field.set(object, columnValue);
                    //
                }

            }

            return object;
        } catch (InstantiationException | IllegalAccessException | NoSuchMethodException |
                 InvocationTargetException | NoSuchFieldException e) {
            throw new RuntimeException("Error creating object from ResultSet: " + e.getMessage());
        }
    }

    // проверка есть ли данное поле в самом классе
    public <T> boolean doesObjectContainField(Class<T> objectClass, String fieldName) {
        // получаем все поля из get и public(но public нету не по правилам SOLID)
        for (Field field : objectClass.getDeclaredFields()) {
            if (field.getName().equals(fieldName)) {
                return true;
            }
        }
        for (Field field : objectClass.getFields()) {
            if (field.getName().equals(fieldName)) {
                return true;
            }
        }
        return false;
    }
}
