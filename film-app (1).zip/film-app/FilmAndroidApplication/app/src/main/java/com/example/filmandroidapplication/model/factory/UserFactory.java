package com.example.filmandroidapplication.model.factory;

import android.content.Context;

import com.example.filmandroidapplication.model.component.user.UserService;
import com.example.filmandroidapplication.model.component.user.impl.UserServiceImpl;


// DI для работы с user component
public class UserFactory {
    private static UserFactory userFactory = null;

    private UserServiceImpl userService;


    public static UserFactory getInstance() {
        if (userFactory == null) {
            synchronized (UserFactory.class) {
                userFactory = new UserFactory();
            }
        }
        return userFactory;
    }


    public UserService getUserComponent(Context context) {
        if (userService == null) {
            userService = new UserServiceImpl();
        }
        userService.update(context);
        return userService;
    }
}
