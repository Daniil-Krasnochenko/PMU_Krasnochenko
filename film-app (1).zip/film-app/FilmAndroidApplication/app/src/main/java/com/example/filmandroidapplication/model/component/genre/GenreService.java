package com.example.filmandroidapplication.model.component.genre;

import com.example.filmandroidapplication.model.entity.film.Film;
import com.example.filmandroidapplication.model.entity.film.data.Genre;

import java.util.List;

public interface GenreService {

    List<Genre> findAllGenre();

    void put(Film film, List<Genre> genres);

    List<Genre> findGenreByFilm(Film film);



}
