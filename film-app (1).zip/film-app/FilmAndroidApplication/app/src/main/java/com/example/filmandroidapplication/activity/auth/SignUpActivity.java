package com.example.filmandroidapplication.activity.auth;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Patterns;
import android.view.View;

import com.example.filmandroidapplication.databinding.ActivitySignUpBinding;
import com.example.filmandroidapplication.model.component.user.UserService;
import com.example.filmandroidapplication.model.component.user.impl.UserServiceImpl;
import com.example.filmandroidapplication.model.factory.AlertFactory;
import com.example.filmandroidapplication.model.factory.UserFactory;
import com.example.filmandroidapplication.model.service.AlertService;
public class SignUpActivity extends AppCompatActivity {

    // Объявление переменных для связывания представления активности, сервисов пользователя и оповещений
    private ActivitySignUpBinding binding;
    private UserService userService;
    private AlertService alertService;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // Инициализация представления активности с помощью ViewBinding
        binding = ActivitySignUpBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        // Получение экземпляров сервисов пользователя и оповещений
        userService = UserFactory.getInstance().getUserComponent(getBaseContext());
        alertService = AlertFactory.getInstance().getAlertFactory(this);

        // Обработчик нажатия кнопки регистрации
        binding.button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String email = binding.email.getText().toString();
                String password = binding.password.getText().toString();

                // Проверка полей ввода на пустоту и соответствие требованиям
                if (email == null) {
                    alertService.alert("ОК", "Введите почту!");
                } else if (password == null) {
                    alertService.alert("ОК", "Введите пароль!");
                } else if (!isValidEmail(email)) {
                    alertService.alert("OK", "Не правильно введен email");
                } else if (password.length() < 6) {
                    alertService.alert("OK","Минимальная длинна пароля 6 символов");
                } else {
                    // Попытка регистрации пользователя
                    if (userService.regUser(email, password)) {
                        setResult(200);
                        finish();
                    } else {
                        alertService.alert("ОК", "Пользователь с такой почтой уже существует!");
                    }
                }
            }
        });

        // Обработчик нажатия ссылки для перехода на экран входа
        binding.signInLink.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getBaseContext(), SignInActivity.class);
                startActivityForResult(intent,200);
                setResult(200);
                finish();
            }
        });
    }

    // Метод для проверки валидности email
    public static boolean isValidEmail(String email) {
        if (TextUtils.isEmpty(email)) {
            return false;
        }
        return Patterns.EMAIL_ADDRESS.matcher(email).matches();
    }
}