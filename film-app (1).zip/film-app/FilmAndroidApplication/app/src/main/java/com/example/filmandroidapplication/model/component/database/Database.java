package com.example.filmandroidapplication.model.component.database;

import java.util.List;

public interface Database {
    int insert(String sql, Object... args);
   

    // для удобного получения данных из бд используем generic
    <T> T query(String sql, Class<T> tClass, Object... args);

    // для удобного получения листа данных из бд используем generic
    <T> List<T> findAll(String sql, Class<T> tClass, Object... args);
}
