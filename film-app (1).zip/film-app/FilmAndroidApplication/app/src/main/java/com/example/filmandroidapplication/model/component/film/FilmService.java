package com.example.filmandroidapplication.model.component.film;

import com.example.filmandroidapplication.model.entity.film.Film;
import com.example.filmandroidapplication.model.entity.film.data.Country;
import com.example.filmandroidapplication.model.entity.film.data.Genre;
import com.example.filmandroidapplication.model.entity.film.data.Year;
import com.example.filmandroidapplication.model.entity.user.User;

import java.util.List;

public interface FilmService {
    int addFilm(String name, String description, String year, String country, String image);

    List<Film> findFilmList();

    List<Film> findFilmList(User user);

    void addFavorite(Film film, User user);

    void removeFavorite(Film film, User user);

    List<Film> findFavoriteFilmList(User user);

    Film getFilmById(Integer id);

    Film getFilmByIdForUser(Integer id, User user);


    List<Film> findFilmByParameters(List<Genre> genres, Year year, Country country, String query);
    List<Film> findFilmByParameters(List<Genre> genres, Year year, Country country, String query,User user);
}
