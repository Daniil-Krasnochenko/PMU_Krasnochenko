package com.example.filmandroidapplication.model.component.film.impl;

import android.util.Log;

import com.example.filmandroidapplication.model.component.database.Database;
import com.example.filmandroidapplication.model.component.film.FilmService;
import com.example.filmandroidapplication.model.component.genre.GenreService;
import com.example.filmandroidapplication.model.entity.film.Film;
import com.example.filmandroidapplication.model.entity.film.data.Country;
import com.example.filmandroidapplication.model.entity.film.data.Genre;
import com.example.filmandroidapplication.model.entity.film.data.Year;
import com.example.filmandroidapplication.model.entity.user.User;
import com.example.filmandroidapplication.model.factory.DatabaseFactory;
import com.example.filmandroidapplication.model.factory.GenreFactory;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class FilmServiceImpl implements FilmService {

    private Database database;
    private GenreService genreService;


    public FilmServiceImpl() {
        database = DatabaseFactory.getInstance().getDatabase();
        genreService = GenreFactory.getInstance().genreService();
    }

    // добавить фильм (и сами данные для фильма)
    @Override
    public int addFilm(String name, String description, String year, String country, String image) {
        String sql = "INSERT INTO film (name, description, year, country, image) VALUES (?, ?, ?, ?, ?)";
        return database.insert(sql, name, description, year, country, image);
    }

    // получить все фильмы для неавторизованного пользователя (не показывает получается избранные фильмы)
    @Override
    public List<Film> findFilmList() {
        String sql = "SELECT f.*, ( SELECT COUNT(*) FROM comment c WHERE c.film = f.id ) AS comment_count FROM film f";
        return database.findAll(sql, Film.class);
    }

    // получить все фильмы для авторизованных пользователей с учетом избранных
    @Override
    public List<Film> findFilmList(User user) {
        String sql = "SELECT f.*, fav.*, COALESCE(c.comment_count, 0) AS comment_count FROM film f LEFT JOIN favorite fav ON fav.film_id = f.id AND fav.user_id = ? LEFT JOIN ( SELECT film, COUNT(*) AS comment_count FROM comment GROUP BY film ) c ON c.film = f.id";
        return database.findAll(sql, Film.class, String.valueOf(user.getId()));
    }


    // получить только избранные фильмы пользователя
    @Override
    public List<Film> findFavoriteFilmList(User user) {
        String sql = "SELECT favorite.*, film.*, COALESCE(cnt.comment_count, 0) AS comment_count FROM film LEFT JOIN favorite ON favorite.film_id = film.id AND favorite.user_id = ? LEFT JOIN ( SELECT film, COUNT(*) AS comment_count FROM comment GROUP BY film ) cnt ON cnt.film = film.id WHERE favorite.user_id IS NOT NULL";
        return database.findAll(sql, Film.class, String.valueOf(user.getId()));
    }

    // получить film по ID ( не авторизованного т.е. не проверить избранное и нельзя добавить или удалить)
    @Override
    public Film getFilmById(Integer id) {
        String sql = "SELECT f.*, ( SELECT COUNT(*) FROM comment c WHERE c.film = f.id ) AS comment_count FROM film f WHERE f.id = ?";
        return database.query(sql, Film.class, id);
    }

    // получить фальм по id для пользователя(авторизованного)
    @Override
    public Film getFilmByIdForUser(Integer id, User user) {
        String sql = "SELECT f.*, fav.*, COALESCE(c.comment_count, 0) AS comment_count FROM film f LEFT JOIN favorite fav ON fav.film_id = f.id AND fav.user_id = ? LEFT JOIN ( SELECT film, COUNT(*) AS comment_count FROM comment GROUP BY film ) c ON c.film = f.id WHERE f.id = ?";
        return database.query(sql, Film.class, user.getId(), id);
    }


    // получить фильмы по фильтрам и строке поиска для неавторизованного пользователя
    @Override
    public List<Film> findFilmByParameters(List<Genre> genres, Year year, Country country, String query) {


        // создаем лист передоваемых данных
        List<Object> objects = new ArrayList<>();

        // создаем лист для добавочных sql параметров
        List<String> list = new ArrayList<>();

        // добавления года если он выбран
        if (year != null && year.getYear() != null) {
            String yearSql = "year = ?";
            list.add(yearSql);
            objects.add(year.getText());
        }
        // добавления страны если она указана
        if (country != null && !country.getCountry().equals("Нет")) {
            String countrySql = "country = ?";
            list.add(countrySql);
            objects.add(country.getCountry());
        }

        // сама строка поиска(может быть и пустой)
        if (query != null && query.isEmpty() == false) {
            String querySql = "(name LIKE ? OR description LIKE ?)";
            list.add(querySql);
            query = "%" + query + "%";
            objects.add(query);
            objects.add(query);

        }

        String sql = "SELECT f.*, ( SELECT COUNT(*) FROM comment c WHERE c.film = f.id ) AS comment_count FROM film f";
        // если лист с годом и страной добавлен, то присоединяем к sql запросу
        if (list.size() > 0) {
            sql += " WHERE " + String.join(" AND ", list.stream().toArray(String[]::new));
        }

        Log.e("[SQL]", sql);


        // поиск всех фильмов
        List<Film> films = database.findAll(sql, Film.class, objects.stream().toArray(String[]::new));

        // если есть жанры по фильтрам то надо удалить ненужные фильмы
        if (genres.size() == 0) {
            return films;
        }

        List<Film> filmsResult = new ArrayList<>();

        // удаляем ненужные
        for (Film film : films) {
            List<Genre> genreList = genreService.findGenreByFilm(film);

            for (Genre genreFromFilm : genreList) {
                boolean flag = false;
                for (Genre genre : genres) {
                    if (genre.getName().equals(genreFromFilm.getName())) {
                        flag = true;
                        filmsResult.add(film);
                        break;
                    }
                }
                if (flag == true) {
                    break;
                }
            }
        }

        return filmsResult;

    }


    // см метод выше
    // получить список фильмов по фильтрам и строке поиска с учетом авторизованного пользователя
    @Override
    public List<Film> findFilmByParameters(List<Genre> genres, Year year, Country country, String query, User user) {
        List<Object> objects = new ArrayList<>();

        List<String> list = new ArrayList<>();


        objects.add(user.getId());


        if (year != null && year.getYear() != null) {
            String yearSql = "year = ?";
            list.add(yearSql);
            objects.add(year.getText());
        }
        if (country != null && !country.getCountry().equals("Нет")) {
            String countrySql = "country = ?";
            list.add(countrySql);
            objects.add(country.getCountry());
        }

        if (query != null && query.isEmpty() == false) {
            String querySql = "(name LIKE ? OR description LIKE ?)";
            list.add(querySql);
            query = "%" + query + "%";
            objects.add(query);
            objects.add(query);

        }


        String sql = "SELECT favorite.*, film.*, COALESCE(cnt.comment_count, 0) AS comment_count FROM film LEFT JOIN favorite ON favorite.film_id = film.id AND favorite.user_id = ? LEFT JOIN ( SELECT film, COUNT(*) AS comment_count FROM comment GROUP BY film ) cnt ON cnt.film = film.id";
        if (list.size() > 0) {
            sql += " WHERE " + String.join(" AND ", list.stream().toArray(String[]::new));
        }

        Log.e("[SQL]", sql);


        List<Film> films = database.findAll(sql, Film.class, objects.stream().toArray());

        if (genres.size() == 0) {
            return films;
        }

        List<Film> filmsResult = new ArrayList<>();

        for (Film film : films) {
            List<Genre> genreList = genreService.findGenreByFilm(film);

            for (Genre genreFromFilm : genreList) {
                boolean flag = false;
                for (Genre genre : genres) {
                    if (genre.getName().equals(genreFromFilm.getName())) {
                        flag = true;
                        filmsResult.add(film);
                        break;
                    }
                }
                if (flag == true) {
                    break;
                }
            }
        }

        return filmsResult;

    }


    // добавить фильм в избранное
    @Override
    public void addFavorite(Film film, User user) {
        Log.e("[FILM]", film.toString());
        String sql = "INSERT INTO favorite (user_id,film_id) VALUES (?,?);";
        database.insert(sql, user.getId(), film.getId());
    }

    // удалить фильм из избранного
    @Override
    public void removeFavorite(Film film, User user) {
        String sql = "DELETE FROM favorite WHERE user_id = ? AND film_id = ?";
        database.insert(sql, user.getId(), film.getId());
    }
}
