package com.example.filmandroidapplication.activity.film;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.util.Base64;
import android.util.DisplayMetrics;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.Spinner;

import com.example.filmandroidapplication.R;
import com.example.filmandroidapplication.adapter.GenreFilterAdapter;
import com.example.filmandroidapplication.config.Config;
import com.example.filmandroidapplication.databinding.ActivityCreateFilmBinding;
import com.example.filmandroidapplication.model.component.film.FilmService;
import com.example.filmandroidapplication.model.component.genre.GenreService;
import com.example.filmandroidapplication.model.entity.film.Film;
import com.example.filmandroidapplication.model.entity.film.data.Genre;
import com.example.filmandroidapplication.model.factory.AlertFactory;
import com.example.filmandroidapplication.model.factory.FilmFactory;
import com.example.filmandroidapplication.model.factory.GenreFactory;
import com.example.filmandroidapplication.model.service.AlertService;

import java.io.ByteArrayOutputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

public class CreateFilmActivity extends AppCompatActivity {

    private static final int PICK_IMAGE_REQUEST = 1;

    //service DI
    private GenreService genreService;
    private AlertService alertService;
    private FilmService filmService;


    // variables
    private String base64Image = null;
    private String country = null;
    private Spinner spinner = null;
    private ActivityCreateFilmBinding binding;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityCreateFilmBinding.inflate(getLayoutInflater());

        setContentView(binding.getRoot());

        // start DI
        alertService = AlertFactory.getInstance().getAlertFactory(this);
        filmService = FilmFactory.getInstance().filmService();
        genreService = GenreFactory.getInstance().genreService();
        //end DI

        // устанавливаем список стран spinner'у (выпадающему списку)
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, Config.country);

        binding.spinner.setAdapter(adapter);
        binding.spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                country = (String) parent.getItemAtPosition(position);

            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        binding.selectPhotoButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openGallery();
            }
        });


        List<Genre> genres = genreService.findAllGenre();
        GenreFilterAdapter genreFilterAdapter = new GenreFilterAdapter(this, R.layout.film_view, genres);
        binding.genresOfFilm.setAdapter(genreFilterAdapter);


        DisplayMetrics metrics = getResources().getDisplayMetrics();

        int dp = 40 * genres.size();
        ; // your desired height in dp

        int heightPx = (int) (dp * metrics.density);

        binding.genresOfFilm.getLayoutParams().height = heightPx;

        binding.addfilmbutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String name = binding.nameFilm.getText().toString();
                String description = binding.descriptionFilm.getText().toString();
                String year = binding.yearOfFilm.getText().toString();

                // country
                // base64Image
                if (base64Image == null) {
                    alertService.alert("OK", "Выберите фото");
                } else if (name == null) {
                    alertService.alert("ОК", "Введите название фильма");
                } else if (description == null) {
                    alertService.alert("ОК", "Введите описание фильма");
                } else if (year == null) {
                    alertService.alert("ОК", "Введите год создания фильма");
                } else if (name.length() < 10 || name.length() > 150) {

                } else {
                    if (country == null) {
                        country = Config.country[0];
                    }

                    int id = filmService.addFilm(name, description, year, country, base64Image);
                    Film film = filmService.getFilmById(id);
                    genreService.put(film, genreFilterAdapter.getSelected());

                    setResult(200);
                    finish();
                }


            }
        });


    }

    private void openGallery() {
        Intent intent = new Intent();
        intent.setType("image/*");
        intent.setAction(Intent.ACTION_GET_CONTENT);
        startActivityForResult(Intent.createChooser(intent, "Select Picture"), PICK_IMAGE_REQUEST);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == PICK_IMAGE_REQUEST && resultCode == RESULT_OK && data != null && data.getData() != null) {
            Uri imageUri = data.getData();
            base64Image = convertImageToBase64(imageUri);
            // Здесь вы можете выполнить необходимые действия с выбранным изображением
            // Например, установить его в ImageView
            ImageView imageView = binding.imageView;
            imageView.setImageURI(imageUri);
        }
    }


    private String convertImageToBase64(Uri imageUri) {
        InputStream inputStream;
        try {
            inputStream = getContentResolver().openInputStream(imageUri);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
            return null;
        }

        byte[] bytes;
        byte[] buffer = new byte[8192];
        int bytesRead;
        ByteArrayOutputStream output = new ByteArrayOutputStream();
        try {
            while ((bytesRead = inputStream.read(buffer)) != -1) {
                output.write(buffer, 0, bytesRead);
            }
        } catch (IOException e) {
            e.printStackTrace();
            return null;
        }
        bytes = output.toByteArray();

        return Base64.encodeToString(bytes, Base64.DEFAULT);
    }


}