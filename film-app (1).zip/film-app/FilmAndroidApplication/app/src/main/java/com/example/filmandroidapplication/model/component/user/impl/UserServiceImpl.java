package com.example.filmandroidapplication.model.component.user.impl;

import android.content.Context;
import android.content.SharedPreferences;

import com.example.filmandroidapplication.model.component.database.Database;
import com.example.filmandroidapplication.model.component.user.UserService;
import com.example.filmandroidapplication.model.entity.user.User;
import com.example.filmandroidapplication.model.factory.DatabaseFactory;


// Компонент для работы с пользователем
public class UserServiceImpl implements UserService {
    private User user;
    private SharedPreferences sharedPreferences;
    private Database database;


    public UserServiceImpl() {
        //подключение к бд через Instance
        database = DatabaseFactory.getInstance().getDatabase();
    }

    // обновление sharedPreferences
    public void update(Context context) {
        sharedPreferences = context.getSharedPreferences("root", Context.MODE_PRIVATE);
    }

    // регистрация пользователя с данными из edit text
    public boolean regUser(String email, String password) {
        if (getUserByEmail(email) != null) {
            return false;
        }
        String sql = "INSERT INTO users (email, password) VALUES (?, ?)";
        database.insert(sql, email, password);
        saveData(email, password);
        return true;
    }


    // автоматическая авторизация из памяти
    public User auth() {
        String email = sharedPreferences.getString("email", null);
        String password = sharedPreferences.getString("password", null);

        if (email == null || password == null) {
            return null;
        }
        String sql = "SELECT * FROM `users` WHERE `email` = ? AND `password` = ?";
        User user = database.query(sql, User.class, email, password);
        return user;
    }


    // авторизация пользователя по переменным из активити авторизации
    public User authUser(String email, String password) {
        if (email == null || password == null) {
            return null;
        }
        String sql = "SELECT * FROM `users` WHERE `email` = ? AND `password` = ?";
        User user = database.query(sql, User.class, email, password);
        if (user != null) {
            saveData(email, password);
        }
        return user;
    }


    // сохранение пароля и почты
    private void saveData(String email, String password) {
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString("email", email);
        editor.putString("password", password);
        editor.commit(); // или editor.apply();
    }

    // проверка занят ли этот email
    public User getUserByEmail(String email) {
        if (email == null) {
            return null;
        }
        String sql = "SELECT * FROM `users` WHERE `email` = ?";
        User user = database.query(sql, User.class, email);
        return user;
    }

    // получить пользователя из памяти и сразу проверить его на авторизацию
    @Override
    public User getUser() {
        if (user != null) {
            return user;
        } else {
            user = auth();
            return user;
        }
    }


}
