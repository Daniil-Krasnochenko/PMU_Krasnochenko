package com.example.filmandroidapplication.model.service.impl;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.widget.Toast;

import com.example.filmandroidapplication.R;
import com.example.filmandroidapplication.model.service.AlertService;

public class AlertServiceImpl implements AlertService {

    private Activity activity;

    public AlertServiceImpl(Activity activity) {
        this.activity = activity;
    }

    // реализация функции,которая будет выполнять какое то действие по нажатию на кноку (с названием ОК в основном) (String button)
    @Override
    public void alert(String button, String body, DialogInterface.OnClickListener listener) {
        AlertDialog.Builder builder = new AlertDialog.Builder(activity);
        builder.setTitle("Уведомление")
                .setMessage(body)
                .setPositiveButton(button, new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        // Закрываем диалоговое окно
                        dialog.cancel();

                        // выполняем какое то действие, передавая Dialog на случай если потребуется
                        listener.onClick(dialog, id);
                    }
                });
        builder.create();
        builder.show();
    }

    // Просто уведомление

    @Override
    public void alert(String button, String body) {
        AlertDialog.Builder builder = new AlertDialog.Builder(activity);
        builder.setTitle("Уведомление")
                .setMessage(body)
                .setPositiveButton(button, new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        // Закрываем диалоговое окно
                        dialog.cancel();
                    }
                });
        builder.create();
        builder.show();


        //Toast.makeText(activity, body, Toast.LENGTH_LONG).show();
    }


}
