package com.example.filmandroidapplication.activity.film.ui;

import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.example.filmandroidapplication.databinding.FragmentCommentViewBinding;
import com.example.filmandroidapplication.model.entity.comment.Comment;

public class CommentViewFragment extends Fragment {

    private FragmentCommentViewBinding binding;
    private Comment comment;

    public CommentViewFragment(Comment comment) {
        this.comment = comment;
    }


    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        binding = FragmentCommentViewBinding.inflate(inflater, container, false);


        binding.commentAuthor.setText(comment.getEmail());
        binding.commentText.setText(comment.getComment());

        return binding.getRoot();
    }
}