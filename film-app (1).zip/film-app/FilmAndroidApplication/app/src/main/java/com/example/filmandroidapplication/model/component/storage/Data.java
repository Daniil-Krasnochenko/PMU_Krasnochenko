package com.example.filmandroidapplication.model.component.storage;

import com.example.filmandroidapplication.model.entity.film.data.Country;
import com.example.filmandroidapplication.model.entity.film.data.Genre;
import com.example.filmandroidapplication.model.entity.film.data.Year;

import java.util.ArrayList;
import java.util.List;

public class Data {
    private List<Genre> genres = new ArrayList<>();
    private Year year;
    private Country country;

    public Data() {
    }

    public List<Genre> getGenres() {
        return genres;
    }

    public void setGenres(List<Genre> genres) {
        this.genres = genres;
    }

    public Year getYear() {
        return year;
    }

    public void setYear(Year year) {
        this.year = year;
    }

    public Country getCountry() {
        return country;
    }

    public void setCountry(Country country) {
        this.country = country;
    }

    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder("Data{");
        sb.append("genres=").append(genres);
        sb.append(", year=").append(year);
        sb.append(", country=").append(country);
        sb.append('}');
        return sb.toString();
    }
}
