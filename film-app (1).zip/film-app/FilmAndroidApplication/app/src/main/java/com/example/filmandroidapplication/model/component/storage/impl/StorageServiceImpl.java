package com.example.filmandroidapplication.model.component.storage.impl;

import com.example.filmandroidapplication.model.component.storage.Data;
import com.example.filmandroidapplication.model.component.storage.StorageService;

import java.util.List;

public class StorageServiceImpl implements StorageService {
    // инкапсуляция(один из принципов SOLID)
    private Data data;


    public StorageServiceImpl() {
        data = new Data();
    }


    // получение данных для поиска
    @Override
    public Data getData() {
        return data;
    }
}
