package com.example.filmandroidapplication.adapter;


import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.util.Base64;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;

import com.example.filmandroidapplication.activity.film.FilmViewActivity;
import com.example.filmandroidapplication.databinding.FilmViewBinding;
import com.example.filmandroidapplication.databinding.FragmentFavoriteBinding;
import com.example.filmandroidapplication.model.component.film.FilmService;
import com.example.filmandroidapplication.model.component.user.UserService;
import com.example.filmandroidapplication.model.entity.film.Film;

import java.util.List;

public class FilmFavoriteArrayAdapter extends ArrayAdapter<Film> implements AdapterView.OnItemClickListener {

    private Activity activity;
    private Context context;
    private List<Film> dataList;
    private UserService userService;
    private FilmService filmService;

    private FragmentFavoriteBinding binding;

    public FilmFavoriteArrayAdapter(Activity activity, int resourceId, List<Film> dataList, FilmService filmService, UserService userService, FragmentFavoriteBinding binding) {
        super(activity.getApplicationContext(), resourceId, dataList);

        this.activity = activity;
        this.context = activity.getApplicationContext();
        this.dataList = dataList;
        this.filmService = filmService;
        this.userService = userService;
        this.binding = binding;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);

        FilmViewBinding filmViewBinding = FilmViewBinding.inflate(inflater);
        Film item = dataList.get(position);

        // установка данных из entity
        filmViewBinding.country.setText(item.getCountry());
        filmViewBinding.name.setText(item.getName());
        filmViewBinding.desc.setText(item.getDescription().substring(0, item.getDescription().length() > 200 ? 200 : item.getDescription().length() - 1));
        filmViewBinding.yearOfFilmView.setText(String.valueOf(item.getYear()) + " год");
        filmViewBinding.comments.setText(item.getComment_count() + " Отзывов");

        filmViewBinding.photo.setImageBitmap(base64ToBitmap(item.getImage()));


        // проверка на добавленное видео в избранное
        if (item.getFilm_id() == null) {

            filmViewBinding.fav.setImageDrawable(context.getResources().getDrawable(android.R.drawable.star_big_off));
        } else {

            filmViewBinding.fav.setImageDrawable(context.getResources().getDrawable(android.R.drawable.star_big_on));
        }

        // обработка нажатия на избранное
        filmViewBinding.fav.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (userService.getUser() != null) {
                    if (item.getFilm_id() == null) {
                        filmService.addFavorite(item, userService.getUser());
                        item.setFilm_id(1);
                    } else {
                        filmService.removeFavorite(item, userService.getUser());
                        item.setFilm_id(null);
                    }
                    if (item.getFilm_id() == null) {
                        dataList.remove(item);
                        notifyDataSetChanged();
                        if (dataList.size() == 0) {
                            binding.authLayout.setVisibility(View.GONE);
                            binding.notFound.setVisibility(View.VISIBLE);
                        }
                        filmViewBinding.fav.setImageDrawable(context.getResources().getDrawable(android.R.drawable.star_big_off));
                    } else {

                        filmViewBinding.fav.setImageDrawable(context.getResources().getDrawable(android.R.drawable.star_big_on));
                    }
                }
            }
        });
        Log.e("[FILM]", item.toString());
        return filmViewBinding.getRoot();
    }

    // конвертор изображение в base64
    private Bitmap base64ToBitmap(String base64String) {
        byte[] decodedBytes = Base64.decode(base64String, Base64.DEFAULT);
        return BitmapFactory.decodeByteArray(decodedBytes, 0, decodedBytes.length);
    }

    @Override
    public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
        // Получение выбранного элемента списка
        Film selectedFilm = dataList.get(i);

        // Создание Intent для запуска новой активности
        Intent intent = new Intent(context, FilmViewActivity.class);

        // Передача данных в новую активность (если нужно)
        intent.putExtra("film", selectedFilm.getId());

        // Запуск новой активности
        activity.startActivityForResult(intent, 200);

    }
}