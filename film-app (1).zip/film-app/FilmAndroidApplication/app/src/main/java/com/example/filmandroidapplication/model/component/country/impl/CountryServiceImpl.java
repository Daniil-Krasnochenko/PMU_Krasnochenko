package com.example.filmandroidapplication.model.component.country.impl;

import com.example.filmandroidapplication.model.component.country.CountryService;
import com.example.filmandroidapplication.model.component.database.Database;
import com.example.filmandroidapplication.model.entity.film.data.Country;
import com.example.filmandroidapplication.model.entity.film.data.Year;
import com.example.filmandroidapplication.model.factory.DatabaseFactory;

import java.util.List;

public class CountryServiceImpl implements CountryService {
    private Database database;


    public CountryServiceImpl() {
        database = DatabaseFactory.getInstance().getDatabase();

    }

    // получить все страны (DISTRINCT) тоесть уникальные
    @Override
    public List<Country> findAllCountry() {
        String sql = "SELECT DISTINCT(country) FROM film";
        return database.findAll(sql, Country.class);
    }

    // получить все года которые есть у фильмов
    @Override
    public List<Year> findAllExistYear() {
        String sql = "SELECT DISTINCT(year) FROM film";
        return database.findAll(sql, Year.class);
    }
}
