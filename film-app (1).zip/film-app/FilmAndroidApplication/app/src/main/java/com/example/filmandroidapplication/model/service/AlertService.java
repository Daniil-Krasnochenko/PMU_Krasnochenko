package com.example.filmandroidapplication.model.service;

import android.app.Activity;
import android.content.DialogInterface;

public interface AlertService {

    void alert(String button, String body, DialogInterface.OnClickListener listener);

    void alert(String button, String body);
}
