package com.example.filmandroidapplication.model.factory;

import com.example.filmandroidapplication.model.component.country.CountryService;
import com.example.filmandroidapplication.model.component.country.impl.CountryServiceImpl;

// DI CountryService с реализацией CountryServiceImpl
public class CountryFactory {
    private static CountryFactory countryFactory;


    private CountryFactory() {

    }

    public static CountryFactory getInstance() {
        if (countryFactory == null) {
            synchronized (CountryFactory.class) {
                countryFactory = new CountryFactory();
            }
        }
        return countryFactory;
    }


    public CountryService countryService() {
        return new CountryServiceImpl();
    }
}
