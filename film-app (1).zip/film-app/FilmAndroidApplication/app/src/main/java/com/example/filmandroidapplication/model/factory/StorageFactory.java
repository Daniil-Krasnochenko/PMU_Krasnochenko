package com.example.filmandroidapplication.model.factory;

import com.example.filmandroidapplication.model.component.storage.StorageService;
import com.example.filmandroidapplication.model.component.storage.impl.StorageServiceImpl;


// более сложна реализация StorageServiceImpl для StorageService (не singlton)
public class StorageFactory {
    private static StorageFactory storageFactory;
    private StorageService storageService;

    private StorageFactory() {

    }

    public static StorageFactory getInstance() {
        if (storageFactory == null) {
            synchronized (StorageFactory.class) {
                storageFactory = new StorageFactory();
            }
        }
        return storageFactory;
    }


    public StorageService storageService() {
        if (storageService == null) {
            synchronized (StorageService.class) {
                synchronized (StorageServiceImpl.class) {
                    storageService = new StorageServiceImpl();
                }

            }
        }
        return storageService;
    }


    public void updateStorage() {
        synchronized (StorageService.class) {
            synchronized (StorageServiceImpl.class) {
                storageService = new StorageServiceImpl();
            }

        }
    }
}
